public class Nodo{
    Empleado empleado;
    Nodo siguiente;

    public Nodo(Empleado empleado){
        this.empleado=empleado;
        this.siguiente=null;
    }
}
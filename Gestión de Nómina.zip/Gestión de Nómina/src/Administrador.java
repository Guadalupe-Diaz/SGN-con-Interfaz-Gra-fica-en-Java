import java.io.*;

public class Administrador implements Serializable{
   // private int ID;
    private String usuario;
    private String contra;

    public Administrador(String usuario, String contra){
        this.usuario = usuario;
        this.contra = contra;
    }
    public String getContra(){return contra;}
    public String getUsuario(){return usuario;}
}  


import java.io.*;
import java.util.*;

public class Empleado implements Serializable{
    // Atributos de la clase Empleado
    private int ID;
    private String nombre;
    private String apellidoP;
    private String apellidoM;
    private int edad;
    private String sexo;
    private String direccion;
    private String telefono;
    private String puesto;
    private String departamento;
    private int horas;
    private int costoPorHora;   
    
    // Constructor de la clase Empleado
    public Empleado(int ID,String nombre,String apellidoP,String apellidoM, int edad, String sexo, String direccion, String telefono, String puesto, String departamento, int horas, int costoPorHora){
        this.ID = ID;
        this.nombre = nombre;
        this.apellidoP = apellidoP;
        this.apellidoM = apellidoM;
        this.edad = edad;
        this.sexo = sexo;
        this.direccion = direccion;
        this.telefono = telefono;
        this.puesto = puesto;
        this.departamento = departamento;
        this.horas = horas;
        this.costoPorHora = costoPorHora;
    }
    
    // Métodos setters y getters
    public int getId(){return ID;}
    public void setId(int ID){this.ID = ID;}
    
    public String getNombre(){return nombre;}
    public void setNombre(String nombre){this.nombre = nombre;}
    
    public String getApellidoP(){return apellidoP;}
    public void setApellidoP(String apellidoP){this.apellidoP = apellidoP;}
    
    public String getApellidoM(){return apellidoM;}
    public void setApellidoM(String apellidoM){this.apellidoM = apellidoM;}
    
    public int getEdad(){return edad;}
    public void setEdad(int edad){this.edad = edad;}
    
    public String getSexo(){return sexo;}
    public void setSexo(String sexo){this.sexo = sexo;}
    
    public String getDireccion(){return direccion;}
    public void setDireccion(String direccion){this.direccion = direccion;}
    
    public String getTelefono(){return telefono;}
    public void setTelefono(String telefono){this.telefono = telefono;}
    
    public String getPuesto(){return puesto;}
    public void setPuesto(String puesto){this.puesto = puesto;}
    
    public String getDepartamento(){return departamento;}
    public void setDepartamento(String departamento){this.departamento = departamento;}
    
    public int getHoras(){return horas;}
    public void setHoras(int horas){this.horas = horas;}
    
    public int getCostoPorHora(){return costoPorHora;}
    public void setCostoPorHora(int costoPorHora){this.costoPorHora = costoPorHora;}
    
    @Override
    public String toString(){
        return nombre + " "+ apellidoP + " " + apellidoM + " "+ ID + " " + edad + " " + sexo +" " + direccion + " " + telefono +  " " + puesto + " " + departamento + " " + horas + " " + costoPorHora;
    } 
}
public class NodoEmpleado {
    
    private NodoEmpleado siguiente;
    private Empleado dato;

    public NodoEmpleado(int ID,String nombre,String apellidoP, String apellidoM, int edad, String sexo, String direccion, String telefono, String puesto, String departamento, int horas, int costoPorHora) {
        dato = new Empleado(ID, nombre, apellidoP, apellidoM, edad, sexo, direccion, telefono, puesto, departamento, horas, costoPorHora);
        siguiente = null;
    }
    public NodoEmpleado(Empleado nuevo){
        this.dato = nuevo;
        siguiente = null;
    }
    public void setSiguiente(NodoEmpleado siguiente){this.siguiente = siguiente;}
    public NodoEmpleado getSiguiente(){return siguiente;}
    public Empleado getDato(){return dato;}
    
}
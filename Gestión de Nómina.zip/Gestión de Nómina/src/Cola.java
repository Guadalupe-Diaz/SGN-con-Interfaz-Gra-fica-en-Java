
public class Cola {
    private Nodo frente=null, fin=null;

    boolean isEmpty(){
        return frente==null;
    }
    
    void encolar(Empleado empleadoEncolar){
        Nodo nuevo = new Nodo(empleadoEncolar);
        if (isEmpty()){
            frente = nuevo;
        } else{
            fin.siguiente=nuevo;
        }
        fin=nuevo;
        System.out.println("El empleado ha sido encolado con exito.");
    }
    Empleado desencolar(){
        if(isEmpty()){
            System.out.println("ERROR!!! No hay empleados por desencolar.");
            return null;
        }
        Empleado empleadoDesencolar = frente.empleado;
        frente = frente.siguiente;
        if(frente==null){
            fin=null;
        } 
        System.out.println("Empleado desencolado con éxito.");
        return empleadoDesencolar;
    }
    @Override
    public String toString(){
        if (isEmpty()) {
            return "La cola esta vacía.";
        }
        StringBuilder resultado = new StringBuilder();
        System.out.println("Empleados en cola: ");
        Nodo actual=frente;
        while (actual!=null) {
            resultado.append(actual.empleado.toString()).append("\n");
            actual=actual.siguiente;
        }
        return resultado.toString();
    }
}
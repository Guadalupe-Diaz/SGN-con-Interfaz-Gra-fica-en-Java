public class Pila {
    private NodoEmpleado cima;

    public Pila(){
        this.cima = null;
    }

    public boolean esVacia (){
        if (cima == null)
            return true;
        return false;
    }

    public void push (int ID,String nombre,String apellidoP,String apellidoM, int edad, String sexo, String direccion, String telefono, String puesto, String departamento, int horas, int costoPorHora){
        NodoEmpleado nuevo = new NodoEmpleado(ID, nombre, apellidoP, apellidoM,edad, sexo, direccion, telefono, puesto, departamento, horas,costoPorHora);
        if (esVacia()){
            cima = nuevo;
            return;
        }
        nuevo.setSiguiente(cima);
        cima = nuevo;
    }

    public void push(NodoEmpleado aux){
        NodoEmpleado nuevo = aux;
        if (esVacia()){
            cima = nuevo;
            return;
        }
        nuevo.setSiguiente(cima);
        cima = nuevo;
    }

    public NodoEmpleado pop (){
        if (esVacia()){
            return null;
        }
        NodoEmpleado aux = cima;
        cima = cima.getSiguiente();
        aux.setSiguiente(null);
        return aux;
    }
    @Override
    public String toString(){
        if (esVacia()) {
            return "Pila de eliminaciones vacia";
        }else{
        StringBuilder resultado = new StringBuilder();
        System.out.println("Empleados en cola: ");
        NodoEmpleado actual=cima;
        while (actual != null) {
            resultado.append(actual.getDato().toString()).append("\n");
            actual=actual.getSiguiente();
        }
        return resultado.toString();
    }
    }
}
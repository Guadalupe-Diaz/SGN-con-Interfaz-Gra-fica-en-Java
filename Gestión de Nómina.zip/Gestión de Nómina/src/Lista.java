public class Lista {
    private NodoEmpleado raiz;
    public Lista() { raiz = null; }
    public boolean esVacia() { return (raiz == null); }

    public void insertarOrdenado(int ID,String nombre, String apellidoP, String apellidoM, int edad, String sexo, String direccion, String telefono, String puesto, String departamento, int horas, int costoPorHora) {
    NodoEmpleado nuevo = new NodoEmpleado(ID,nombre, apellidoP, apellidoM, edad,sexo,direccion,telefono,puesto,departamento,horas,costoPorHora);

        // Caso 1: El elemento se inserta en la raíz
        if (esVacia()) {
            raiz = nuevo;
            return;
        }
        // Caso 2: El elemento es menor que la raíz
        if (raiz.getDato().getNombre().compareTo(nuevo.getDato().getNombre()) > 0) {
            nuevo.setSiguiente(raiz);
            raiz = nuevo;
            return;
        }
            NodoEmpleado aux = raiz;
            while (aux.getSiguiente() != null && aux.getSiguiente().getDato().getNombre().compareTo(nuevo.getDato().getNombre()) < 0) {
            aux = aux.getSiguiente();
        }
        // Caso 3: El elemento se inserta al final de la lista
        if (aux.getSiguiente() == null) {
            aux.setSiguiente(nuevo);
            return;
        }
        // Caso 4: El elemento se inserta en medio
        nuevo.setSiguiente(aux.getSiguiente());
        aux.setSiguiente(nuevo);
    }

    public void mostrarLista() {
        NodoEmpleado aux = raiz;
        if (aux == null) {
            System.out.println("Lista vacía.");
            return;
        }
        while (aux != null) {
            System.out.println(aux.getDato().toString());
            System.out.println();
            aux = aux.getSiguiente();
        }
    }

    public void eliminarUsuario(int i) {
        
        if(raiz == null){
            return;
        }
        // Caso 0: eliminar la raiz cuando solo hay un solo elemento
        if (raiz.getDato().getId() == i && raiz.getSiguiente() == null) {
            raiz = null;
            return;
        }

        // Caso 1: La raíz es el elemento a eliminar
        if (raiz.getDato().getId()==i) {
            if (raiz.getSiguiente() == null) {
                raiz.setSiguiente(null);
                raiz = null;
                return;
            }
            raiz = raiz.getSiguiente();
            return;
        }
        NodoEmpleado aux = raiz;
        while (aux.getSiguiente() != null && aux.getSiguiente().getDato().getId() != i) {
            aux = aux.getSiguiente();
        }
        // Caso 2: Elemento NO encontrado
        if (aux.getSiguiente() == null) {
            System.out.println("Usuario NO encontrado");
            return;
        }
        // Caso 3: El último nodo de la lista es el elemento a eliminar
        if (aux.getSiguiente().getSiguiente() == null && aux.getSiguiente().getDato().getId() == i) {
            aux.setSiguiente(aux.getSiguiente().getSiguiente());
            return;
        }
        // Caso 4: El elemento a eliminar está en medio
            aux.setSiguiente(aux.getSiguiente().getSiguiente());
            return;
        }

    public void actualizarUsuario(int id,String nombre, String apellidoP, String apellidoM, int edad, String sexo, String direccion, String telefono, String puesto, String departamento, int horas, int costoPorHora) {
        if (esVacia()) {
            System.out.println("Lista vacía.");
            return;
        }

        NodoEmpleado actual = raiz;

        while (actual != null && actual.getDato().getId() != id) {
            actual = actual.getSiguiente();
        }

        if (actual == null) {
            System.out.println("Usuario no encontrado.");
            return;
        }

        eliminarUsuario(id);
        insertarOrdenado(id, nombre, apellidoP, apellidoM, edad, sexo, direccion, telefono, puesto, departamento, horas, costoPorHora);
        System.out.println("Usuario actualizado correctamente.");
    }
    }
